import { comparison } from "./certificate.mjs";
import { publicRootFingerprints, publicRootStoreVersion } from "./public-roots.mjs";

export function assessConnection(result, certificatePins, keyPins) {
  const certificateStatus = comparison(result.fingerprint, certificatePins);
  const rootFingerprint = result.root?.fingerprint;
  const rootOnPublicList = rootFingerprint
    ? publicRootFingerprints.has(rootFingerprint) : null;
  const publicList = `扩展内置的 Chrome 公共根证书清单（版本 ${publicRootStoreVersion}）`;
  const rootEvidence = rootOnPublicList === true
    ? `根证书指纹命中${publicList}。`
    : rootOnPublicList === false
      ? `根证书指纹未命中${publicList}。可能使用了私有 CA，或清单与当前 Chrome 版本有差异。`
      : "未取得可核对的根证书指纹。";

  const keyStatus = result.publicKeyFingerprint
    ? comparison(result.publicKeyFingerprint, keyPins) : "unconfigured";
  const cloudStatus = result.tlsBaseline?.status;
  const manualMatch = certificateStatus === "match" || keyStatus === "match";
  const cloudMatch = cloudStatus === "匹配" || cloudStatus === "公钥匹配";

  if (manualMatch || cloudMatch) {
    const source = manualMatch ? "手动基准" : "云端 TLS 基准";
    const fullCertificateMatch = certificateStatus === "match" || cloudStatus === "匹配";
    const conflictingEvidence = certificateStatus === "mismatch" || keyStatus === "mismatch" ||
      cloudStatus === "不匹配";
    const evidence = fullCertificateMatch ? "本次探测的站点证书指纹已核对一致。"
      : "本次探测的站点公钥指纹已核对一致。";
    return {
      status: "match",
      title: manualMatch && cloudMatch ? "手动和云端 TLS 基准均有匹配"
        : `站点${fullCertificateMatch ? "证书" : "公钥"}与${source}一致`,
      message: evidence + (conflictingEvidence ? "另有指纹与已配置的基准不同，可核对各基准的采集来源和时间。" : ""),
      rootEvidence
    };
  }

  if (keyStatus === "mismatch" || certificateStatus === "mismatch" || cloudStatus === "不匹配") {
    return {
      status: "mismatch",
      title: "站点指纹与基准不符",
      message: "证书轮换、不同 CDN 节点或 HTTPS 代理重签都可能造成此结果。请用独立可信来源复核。",
      rootEvidence
    };
  }

  return {
    status: rootOnPublicList === false ? "mismatch" : "unconfigured",
    title: rootOnPublicList === false ? "根证书需要复核" : "证据不足，无法判断是否有中间人",
    message: keyPins.length
      ? "请重新检测以读取站点公钥并与已保存的基准比对。"
      : "可使用云端 TLS 基准或填写从独立可信来源取得的证书或公钥指纹。",
    rootEvidence
  };
}
