# HTTPS 证书核对

Chrome 桌面扩展。读取 Chrome 为本次 HTTPS 请求记录的证书，检查站点证书或公钥是否被替换，并查看根证书及其所属机构。

## 加载与使用

1. 解压 ZIP。打开 `chrome://extensions`，开启「开发者模式」，点击「加载已解压的扩展程序」并选中包含 `manifest.json` 的 `chrome-certificate-checker` 目录。升级时覆盖原目录后点击「重新加载」。
2. 打开要核对的 HTTPS 站点，点击「检测 HTTPS 中间人迹象」。Chrome 会显示调试提示，保持调试连接即可。
3. 如需核对站点身份，从站点管理员或独立可信网络取得叶证书或 SPKI 的 SHA-256 指纹，在当前站点的弹窗中保存为基准。支持每行一个指纹。基准按 HTTPS 来源保存，包括域名和端口。证书或公钥任一指纹匹配即可。

如果可信渠道提供了叶证书 PEM，可在 macOS 或 Linux 计算两类指纹。

```sh
openssl x509 -in official-leaf.pem -noout -fingerprint -sha256
openssl x509 -in official-leaf.pem -pubkey -noout |
  openssl pkey -pubin -outform DER |
  openssl dgst -sha256
```

## 判断结果

| 面板结果 | 含义 |
|---|---|
| 站点公钥或证书与可信基准一致 | 本次探测未发现对应指纹被替换的迹象。公钥相同、证书指纹不同，符合使用同一公钥续签的情况。 |
| 站点公钥或证书与基准不符 | 换证、换钥、不同 CDN 节点或 HTTPS 代理重签都可能造成差异。用独立可信来源复核。 |
| 根证书需要复核 | 当前验证链末端识别出的根证书指纹未出现在扩展内置的公开清单里。可能是私有或企业 CA，也可能是清单与本机 Chrome 版本有差异。 |
| 证据不足 | 已取得叶证书，当前来源缺少可用的独立基准。 |
| 检测未完成 | Chrome 未返回可核对的证书，或检测遇到跳转、下载、TLS 错误、调试取消或超时。 |

扩展的公开清单取自 Chromium [Chrome Root Store `trust_anchors`](https://github.com/chromium/chromium/blob/main/net/data/ssl/chrome_root_store/root_store.textproto)，版本 45。扩展仅按整张根证书的 SHA-256 指纹核对清单成员资格，使用的是随扩展发布的快照。命中只表明证书列在该快照中。当前 Chrome 的信任配置、清单中的约束和企业策略仍由 Chrome 自己处理。

## 检测范围

扩展在同一 Chrome 浏览器配置中创建临时标签页，对当前网址发起一次 GET，结果对应这次检测。Chrome 可以复用已有 TLS 连接或会话。此检测针对会替换站点证书或公钥的 HTTPS 中间人，对透明转发、其他站点的连接或能使用真实站点密钥的代理无法作出判断。检测会处理常见的 HTML 和纯文本页面，遇到跳转可在最终地址重试。

`Network.getCertificate` 按来源返回浏览器记录的证书。扩展在空白的临时标签页启用 Network，跳过 HTTP 缓存和 Service Worker，暂停网络请求，只放行目标的一个主文档请求。Chrome 返回安全的 HTTPS 响应后，扩展从 `Network.getCertificate` 的 `tableNames[0]` 读取叶证书的 Base64 DER，完成后关闭临时标签页。验证链以浏览器记录为准。Chrome 返回的验证链末端为自颁发证书时，面板会显示其 CN、O 和证书指纹。验证链缺少可识别的根证书时，面板显示无法确认；例如信任锚可能是直接信任的非自颁发证书。机构取自根证书的 Subject O，面板未判断信任配置来自 Chrome Root Store、系统证书库或本地策略。基准保存在本地，检测结果保存在当前浏览器会话中。

[Chrome 扩展 debugger API](https://developer.chrome.com/docs/extensions/reference/api/debugger) · [CDP Network](https://chromedevtools.github.io/devtools-protocol/tot/Network/) · [CDP Fetch](https://chromedevtools.github.io/devtools-protocol/tot/Fetch/)

## 查询 Chrome 当前证书信任状态

扩展通过只读查询入口打开 Chrome 原生页面，由当前个人资料显示实际值。

- 系统证书开关对应 `chrome://certificate-manager/localcerts`。
- 自己导入的服务器信任证书对应 `chrome://certificate-manager/localcerts/usercerts`。
- 管理员安装的证书对应 `chrome://certificate-manager/localcerts/admincerts`。通过操作系统下发的证书另在系统证书库核对。
- 系统证书集成策略对应 `chrome://policy` 的 `CAPlatformIntegrationEnabled`。若未设置该策略，系统证书开关仍以证书管理器为准。

要在扩展中查看策略值，可先在 `chrome://policy` 重新加载策略并导出 JSON，再从扩展打开「读取策略 JSON」选择该文件。结果以导出文件为准，读取过程在本地完成。企业证书策略的条目数只代表导出内容，当前已安装的证书以 Chrome 证书管理器为准。

### TLS 基准比对

每次检测自动读取 [tls-baselines.json](https://ai-12345678.github.io/api/tls-baselines.json)。扩展在本地按站点查找基准并比对 SHA-256 证书与公钥指纹。请求地址固定，无需邮箱，也不附带当前访问域名。

结果包括匹配、公钥匹配、不匹配和未知。未知包括站点未收录、基准超过 72 小时、数据缺失或无法下载。云端或手动基准只要匹配一项，主状态即显示匹配。不同基准之间有差异时，主状态会提示复核。证书链详情和云端比对结果仍会显示。

## GitHub Releases

在 [Releases](https://github.com/ai-12345678/chrome-middleman-checker/releases) 下载对应版本的 `chrome-middleman-checker-v<版本>.tar.gz`。解压后，在 `chrome://extensions/` 启用开发者模式，选择「加载已解压的扩展程序」，打开含有 `manifest.json` 的目录。

更新 `manifest.json` 的 `version` 并推送到 `main` 时，GitHub Actions 会构建新的 tar 包并发布对应版本。推送与清单版本一致的 `v<版本>` 标签也会触发发布。已发布的同名附件不会被覆盖。
