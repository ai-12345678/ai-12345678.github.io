export const baselineUrl = "https://ai-12345678.github.io/api/tls-baselines.json";
const maxAge = 72 * 60 * 60 * 1000;

function fingerprint(value) {
  return typeof value === "string" && /^[a-f0-9]{64}$/i.test(value) ? value.toLowerCase() : null;
}

export function compareBaseline(document, result, now = Date.now()) {
  const url = new URL(result.origin);
  if (document?.version !== 1 || !document.hosts || typeof document.hosts !== "object") {
    return { status: "未知", message: "基准文件格式无效。" };
  }
  const baseline = !url.port && Object.hasOwn(document.hosts, url.hostname)
    ? document.hosts[url.hostname] : null;
  if (!baseline) return { status: "未知", message: "基准文件未收录当前站点。" };
  const observedAt = Date.parse(baseline.observedAt);
  const cert = fingerprint(baseline.certificateSha256);
  const key = fingerprint(baseline.spkiSha256);
  const localCert = fingerprint(result.fingerprint);
  const localKey = fingerprint(result.publicKeyFingerprint);
  if (!Number.isFinite(observedAt) || observedAt > now || now - observedAt > maxAge ||
      !cert || !key || !localCert || !localKey) {
    return { status: "未知", message: "基准过期或指纹数据不完整。" };
  }
  if (cert === localCert && key === localKey) {
    return { status: "匹配", message: "证书和公钥均与云端基准一致。", observedAt };
  }
  if (key === localKey) {
    return { status: "公钥匹配", message: "公钥一致，证书指纹不同，可能发生了证书续签。", observedAt };
  }
  if (cert === localCert) {
    return { status: "未知", message: "证书与公钥比对结果不一致，请核查基准。", observedAt };
  }
  return { status: "不匹配", message: "证书和公钥均不同。CDN 节点差异或证书轮换也可能造成此结果。", observedAt };
}

export async function compareWithTlsBaseline(result) {
  try {
    const response = await fetch(baselineUrl, {
      cache: "no-cache", credentials: "omit", referrerPolicy: "no-referrer",
      redirect: "error", signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) {
      return { status: "未知", message: `基准请求失败（HTTP ${response.status}）。` };
    }
    return compareBaseline(await response.json(), result);
  } catch {
    return { status: "未知", message: "无法读取云端基准。" };
  }
}
