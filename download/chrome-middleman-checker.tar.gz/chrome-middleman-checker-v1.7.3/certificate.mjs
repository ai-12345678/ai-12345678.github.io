export function httpsUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password) {
    throw new Error("请选择一个使用 HTTPS 的网页。");
  }
  url.hash = "";
  return url;
}

export function parseFingerprints(value) {
  const lines = value.trim().split(/\r?\n/).filter(line => line.trim());
  return [...new Set(lines.map(line => {
    const fingerprint = line.trim().replace(/^SHA-?256\s+Fingerprint\s*=\s*/i, "");
    if (!/^(?:[\da-f]{64}|[\da-f]{2}(?::[\da-f]{2}){31})$/i.test(fingerprint)) {
      throw new Error("每行填写一个 SHA-256 指纹，可用 64 位十六进制或冒号分隔的格式。");
    }
    return fingerprint.replaceAll(":", "").toUpperCase();
  }))];
}

export function displayFingerprint(value) {
  return value.match(/.{2}/g).join(":");
}

function readDer(bytes, offset = 0) {
  const start = offset;
  const tag = bytes[offset++];
  let size = bytes[offset++];
  if (size >= 128) {
    const count = size & 127;
    if (!count || count > 4 || offset + count > bytes.length) {
      throw new Error("证书 DER 长度无效。");
    }
    size = 0;
    for (let index = 0; index < count; index++) size = size * 256 + bytes[offset++];
  }
  const end = offset + size;
  if (!Number.isFinite(end) || end > bytes.length) throw new Error("证书 DER 数据不完整。");
  return { tag, end, content: bytes.subarray(offset, end), encoded: bytes.subarray(start, end) };
}

function children(node, tag) {
  if (node?.tag !== tag) throw new Error("证书 DER 结构无效。");
  const items = [];
  for (let offset = 0; offset < node.content.length;) {
    const item = readDer(node.content, offset);
    items.push(item);
    offset = item.end;
  }
  return items;
}

const nameFields = { 3: "cn", 10: "o", 11: "ou" };

function readName(node) {
  const name = {};
  for (const set of children(node, 0x30)) {
    for (const entry of children(set, 0x31)) {
      const [oid, value] = children(entry, 0x30);
      const code = oid?.content;
      const field = oid?.tag === 6 && code.length === 3 && code[0] === 0x55 &&
        code[1] === 4 && nameFields[code[2]];
      if (!field || !value) continue;
      let decoded;
      switch (value.tag) {
        case 0x1e:
          decoded = new TextDecoder("utf-16be").decode(value.content);
          break;
        case 0x1c: {
          const codePoints = new DataView(value.content.buffer, value.content.byteOffset,
            value.content.byteLength);
          decoded = "";
          for (let offset = 0; offset + 4 <= codePoints.byteLength; offset += 4) {
            const codePoint = codePoints.getUint32(offset);
            decoded += String.fromCodePoint(codePoint <= 0x10ffff ? codePoint : 0xfffd);
          }
          break;
        }
        default:
          decoded = new TextDecoder(value.tag === 0x14 ? "windows-1252" : "utf-8")
            .decode(value.content);
      }
      name[field] = name[field] ? `${name[field]} / ${decoded}` : decoded;
    }
  }
  return name;
}

async function sha256(bytes) {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0"))
    .join("").toUpperCase();
}

async function readCertificate(base64Der) {
  const der = Uint8Array.from(atob(base64Der), char => char.charCodeAt(0));
  const certificate = readDer(der);
  if (certificate.end !== der.length) throw new Error("证书 DER 含有额外数据。");
  const [tbs] = children(certificate, 0x30);
  const fields = children(tbs, 0x30);
  const offset = fields[0]?.tag === 0xa0 ? 1 : 0;
  const [issuer, , subject, spki] = fields.slice(offset + 2, offset + 6);
  if (spki?.tag !== 0x30) throw new Error("无法读取证书公钥。");

  const [fingerprint, publicKeyFingerprint] = await Promise.all([sha256(der), sha256(spki.encoded)]);
  return {
    subject: readName(subject),
    issuer: readName(issuer),
    fingerprint,
    publicKeyFingerprint,
    selfIssued: subject.encoded.length === issuer.encoded.length &&
      subject.encoded.every((byte, index) => byte === issuer.encoded[index])
  };
}

export async function readCertificateDetails(chain) {
  const leaf = await readCertificate(chain[0]);
  const endpoint = chain.length > 1 ? await readCertificate(chain.at(-1)) : leaf;
  return {
    fingerprint: leaf.fingerprint,
    publicKeyFingerprint: leaf.publicKeyFingerprint,
    subjectName: leaf.subject,
    issuerName: leaf.issuer,
    root: endpoint.selfIssued ? {
      commonName: endpoint.subject.cn,
      organization: endpoint.subject.o,
      fingerprint: endpoint.fingerprint
    } : null,
    chainEndpoint: !endpoint.selfIssued && chain.length > 1 ? endpoint.subject : null
  };
}

export function comparison(fingerprint, trusted) {
  if (trusted.length === 0) return "unconfigured";
  return trusted.includes(fingerprint) ? "match" : "mismatch";
}
