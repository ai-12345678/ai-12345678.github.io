import { httpsUrl, readCertificateDetails } from "./certificate.mjs";

const PROBE_TIMEOUT_MS = 18_000;
const CERTIFICATE_POLL_MS = 200;
const INLINE_DOCUMENT_TYPES = new Set([
  "text/html", "text/plain", "text/xml", "application/xhtml+xml", "application/json", "application/xml"
]);

export async function inspectCertificate(originalTab) {
  const url = httpsUrl(originalTab.url);
  const probeTab = await chrome.tabs.create({
    windowId: originalTab.windowId,
    active: false,
    url: "about:blank"
  });
  const target = { tabId: probeTab.id };
  let attached = false;
  let closing = false;
  let frameId;
  let mainFetchId;
  let mainRequest;
  let failure;
  let cached = false;
  let deliverResponse;
  let cancelCommands;
  const observed = new Promise(resolve => { deliverResponse = resolve; });
  const canceled = new Promise(resolve => { cancelCommands = resolve; });

  async function untilCanceled(operation) {
    const result = await Promise.race([operation, canceled]);
    if (failure) throw new Error(failure);
    return result;
  }

  const send = (method, params) => untilCanceled(chrome.debugger.sendCommand(target, method, params));

  function stop(message) {
    if (closing) return;
    failure ??= message;
    deliverResponse(null);
    cancelCommands();
  }

  function onDetach(source, reason) {
    if (source.tabId !== target.tabId) return;
    attached = false;
    stop(reason === "canceled_by_user" ? "Chrome 的调试连接已取消。" : "检测标签页已关闭。");
  }

  async function handlePaused(event) {
    const isResponse = event.responseStatusCode !== undefined || event.responseErrorReason;
    if (!isResponse && !mainFetchId && !failure && event.frameId === frameId &&
        event.resourceType === "Document" && event.request.method === "GET" &&
        event.request.url === url.href && !event.redirectedRequestId) {
      // Network.getCertificate is keyed by origin. Allow only this one request in the probe.
      mainFetchId = event.requestId;
      mainRequest ??= event.networkId;
      await send("Fetch.continueRequest", { requestId: event.requestId });
      return;
    }

    if (isResponse && mainFetchId && (event.requestId === mainFetchId ||
        (mainRequest && event.networkId === mainRequest))) {
      const headers = event.responseHeaders ?? [];
      const disposition = headers.find(header => header.name.toLowerCase() === "content-disposition");
      const type = headers.find(header => header.name.toLowerCase() === "content-type");
      const mimeType = type?.value.split(";")[0].trim().toLowerCase();
      if (event.responseStatusCode >= 300 && event.responseStatusCode < 400) {
        stop("检测地址返回跳转。请在跳转完成后的页面重新检测。");
      } else if (event.responseErrorReason) {
        stop(`Chrome 未收到可读取的 HTTPS 响应。${event.responseErrorReason}`);
      } else if ((disposition && /^\s*attachment\b/i.test(disposition.value)) ||
                 !INLINE_DOCUMENT_TYPES.has(mimeType)) {
        stop("检测地址返回下载或浏览器可能下载的内容。请选用同一站点的网页。");
      } else if (!failure) {
        await send("Fetch.continueRequest", { requestId: event.requestId });
        return;
      }
    }

    await send("Fetch.failRequest", { requestId: event.requestId, errorReason: "BlockedByClient" });
  }

  function onEvent(source, method, event) {
    if (closing || source.tabId !== target.tabId || source.sessionId) return;
    if (method === "Fetch.requestPaused") {
      handlePaused(event).catch(error => stop(`Chrome 无法完成隔离请求。${error.message}`));
      return;
    }
    if (method === "Network.requestWillBeSent" && event.frameId === frameId &&
        event.type === "Document") {
      if (event.requestId === mainRequest && event.redirectResponse) {
        stop("检测地址返回跳转。请在跳转完成后的页面重新检测。");
      } else if (!event.redirectResponse && event.request.url === url.href) {
        mainRequest ??= event.requestId;
      }
    }
    if (!mainFetchId || !mainRequest || event?.requestId !== mainRequest) return;
    if (method === "Network.requestServedFromCache") cached = true;
    if (method === "Network.loadingFailed") {
      stop(`Chrome 请求失败。${event.errorText}`);
    }
    if (method === "Network.responseReceived" && event.type === "Document") {
      const response = event.response;
      if (response.url === url.href && (!event.frameId || event.frameId === frameId)) {
        deliverResponse(response);
      } else {
        stop("Chrome 返回的文档与本次检测地址不一致。");
      }
    }
  }

  const timer = setTimeout(() => stop("等待 Chrome 返回证书超时。"), PROBE_TIMEOUT_MS);
  chrome.debugger.onDetach.addListener(onDetach);
  chrome.debugger.onEvent.addListener(onEvent);

  try {
    await untilCanceled(chrome.debugger.attach(target, "1.3"));
    attached = true;
    frameId = (await send("Page.getFrameTree")).frameTree.frame.id;
    await send("Network.enable");
    await send("Network.setCacheDisabled", { cacheDisabled: true });
    await send("Network.setBypassServiceWorker", { bypass: true });
    await send("Emulation.setScriptExecutionDisabled", { value: true });
    await send("Fetch.enable", {
      patterns: [
        { urlPattern: "*", requestStage: "Request" },
        { urlPattern: "*", resourceType: "Document", requestStage: "Response" }
      ]
    });
    if (failure) throw new Error(failure);

    send("Page.navigate", { url: url.href }).then(result => {
      if (result.errorText) stop(`Chrome 导航失败。${result.errorText}`);
    }).catch(error => stop(error.message));

    const response = await observed;
    if (failure) throw new Error(failure);
    if (cached || response.fromDiskCache || response.fromPrefetchCache || response.fromServiceWorker ||
        response.securityState !== "secure" || !response.securityDetails) {
      throw new Error("Chrome 未报告本次请求通过安全的 HTTPS 连接取得响应。");
    }

    while (!failure) {
      // The navigation response can arrive before the renderer has recorded its certificate.
      const { tableNames: chain } = await send("Network.getCertificate", { origin: url.origin });
      if (Array.isArray(chain) && chain[0]) {
        const certificate = await readCertificateDetails(chain);
        if (failure) break;
        if (cached) throw new Error("Chrome 返回了缓存响应，无法核对本次连接的证书。");
        const details = response.securityDetails;
        return {
          origin: url.origin,
          checkedAt: Date.now(),
          ...certificate,
          subject: details.subjectName,
          issuer: details.issuer,
          protocol: details.protocol,
          validFrom: details.validFrom,
          validTo: details.validTo
        };
      }
      await new Promise(resolve => setTimeout(resolve, CERTIFICATE_POLL_MS));
    }
    throw new Error(failure);
  } finally {
    closing = true;
    clearTimeout(timer);
    chrome.debugger.onEvent.removeListener(onEvent);
    chrome.debugger.onDetach.removeListener(onDetach);
    // Closing the probe ends interception before queued requests can resume.
    try {
      await chrome.tabs.remove(target.tabId);
    } catch {
      if (attached) await chrome.debugger.detach(target).catch(() => {});
    }
  }
}
