import { readExportedPolicies } from "./policy.mjs";

const input = document.getElementById("policy-file");
const status = document.getElementById("policy-status");
const results = document.getElementById("policy-results");

input.addEventListener("change", async () => {
  results.hidden = true;
  results.replaceChildren();
  status.textContent = "";
  const [file] = input.files;
  if (!file) return;
  input.disabled = true;

  try {
    const policies = readExportedPolicies(await file.text());
    for (const policy of policies) {
      const term = document.createElement("dt");
      term.textContent = policy.name;
      const description = document.createElement("dd");
      description.textContent = policy.status;
      results.append(term, description);
    }
    results.hidden = false;
    status.textContent = "已读取导出文件。";
  } catch (error) {
    status.textContent = error instanceof SyntaxError ? "请选择有效的 Chrome 策略 JSON。" : error.message;
  } finally {
    input.value = "";
    input.disabled = false;
  }
});
