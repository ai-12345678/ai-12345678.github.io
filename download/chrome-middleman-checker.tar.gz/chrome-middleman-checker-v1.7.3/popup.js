import { displayFingerprint, httpsUrl, parseFingerprints } from "./certificate.mjs";
import { assessConnection } from "./interception.mjs";

const element = id => document.getElementById(id);
const inspect = element("inspect");
const baseline = element("baseline");
const trusted = element("trusted");
const trustedKey = element("trusted-key");
const save = element("save");
const resultSection = element("result");
const details = element("details");
const date = new Intl.DateTimeFormat("zh-CN", {
  dateStyle: "medium", timeStyle: "medium", timeZone: "Asia/Shanghai"
});

let pins = [];
let keyPins = [];
let lastResult;

function show(status, title, message) {
  resultSection.hidden = false;
  resultSection.dataset.status = status;
  element("status").textContent = title;
  element("message").textContent = message;
  details.hidden = true;
  element("root-evidence").hidden = true;
  element("probe-scope").hidden = true;
}

function renderResult() {
  if (!lastResult) return;
  const baselineResult = lastResult.tlsBaseline;
  element("external-result").textContent = baselineResult
    ? [baselineResult.status, baselineResult.message,
      baselineResult.observedAt && `采集时间 ${date.format(baselineResult.observedAt)}`].filter(Boolean).join(" · ")
    : "";
  if (lastResult.error) {
    show("error", "检测未完成，无法判断", lastResult.error);
    return;
  }

  const { status, title, message, rootEvidence } = assessConnection(lastResult, pins, keyPins);
  show(status, title, message);
  element("root-evidence").textContent = rootEvidence;
  element("root-evidence").hidden = false;
  element("probe-scope").hidden = false;
  element("fingerprint").textContent = displayFingerprint(lastResult.fingerprint);
  const missing = "未包含在证书中";
  const rerun = "重新检测后显示";
  for (const [prefix, name, previous] of [
    ["subject", lastResult.subjectName, lastResult.subject],
    ["issuer", lastResult.issuerName, lastResult.issuer]
  ]) {
    element(`${prefix}-cn`).textContent = name ? name.cn || missing : previous || rerun;
    element(`${prefix}-o`).textContent = name ? name.o || missing : rerun;
    element(`${prefix}-ou`).textContent = name ? name.ou || missing : rerun;
  }
  element("public-key-fingerprint").textContent = lastResult.publicKeyFingerprint
    ? displayFingerprint(lastResult.publicKeyFingerprint) : rerun;
  element("protocol").textContent = lastResult.protocol || "—";
  for (const [id, seconds] of [
    ["valid-from", lastResult.validFrom], ["valid-to", lastResult.validTo]
  ]) {
    element(id).textContent = Number.isFinite(seconds) ? date.format(seconds * 1000) : "—";
  }

  const root = lastResult.root;
  element("root-details").hidden = !root;
  element("root-message").hidden = !!root;
  if (root) {
    element("root-cn").textContent = root.commonName || missing;
    element("root-o").textContent = root.organization || missing;
    element("root-fingerprint").textContent = displayFingerprint(root.fingerprint);
  } else {
    const endpoint = lastResult.chainEndpoint;
    const endpointName = [endpoint?.cn, endpoint?.o].filter(Boolean).join(" · ");
    element("root-message").textContent = lastResult.root === undefined ? rerun :
      `Chrome 返回的验证链未提供可确认的根证书。${endpointName ? `链末端为 ${endpointName}。` : ""}`;
  }
  element("checked-at").textContent = date.format(lastResult.checkedAt);
  details.hidden = false;
}

async function setup() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let origin;
  try {
    ({ origin } = httpsUrl(tab?.url));
  } catch {
    element("origin").textContent = "请切换到要检测的 HTTPS 标签页。";
    return;
  }

  const pinKey = `trusted:${origin}`;
  const publicKey = `trustedSpki:${origin}`;
  const [stored, session] = await Promise.all([
    chrome.storage.local.get([pinKey, publicKey]),
    chrome.storage.session.get("lastCheck")
  ]);
  pins = stored[pinKey] ?? [];
  keyPins = stored[publicKey] ?? [];
  trusted.value = pins.map(displayFingerprint).join("\n");
  trustedKey.value = keyPins.map(displayFingerprint).join("\n");
  element("origin").textContent = origin;
  element("external-settings").hidden = false;
  baseline.hidden = false;
  inspect.disabled = false;
  if (session.lastCheck?.origin === origin) lastResult = session.lastCheck;
  renderResult();

  baseline.addEventListener("submit", async event => {
    event.preventDefault();
    save.disabled = true;
    try {
      const next = parseFingerprints(trusted.value);
      const nextKeys = parseFingerprints(trustedKey.value);
      await chrome.storage.local.set({ [pinKey]: next, [publicKey]: nextKeys });
      pins = next;
      keyPins = nextKeys;
      trusted.value = pins.map(displayFingerprint).join("\n");
      trustedKey.value = keyPins.map(displayFingerprint).join("\n");
      element("save-message").textContent = pins.length || keyPins.length ? "已保存" : "已清除";
      if (!inspect.disabled) renderResult();
    } catch (error) {
      element("save-message").textContent = error.message;
    } finally {
      save.disabled = false;
    }
  });

  inspect.addEventListener("click", async () => {
    inspect.disabled = true;
    element("external-result").textContent = "";
    show("pending", "检测中", "正在检查本次 HTTPS 证书，并查询 TLS 基准。");
    try {
      const result = await chrome.runtime.sendMessage({ type: "inspect-certificate", tabId: tab.id, origin });
      if (result?.busy) {
        show("pending", "已有检测进行中", "检测完成后，重新打开面板即可查看结果。");
      } else if (result?.origin === origin) {
        lastResult = result;
        renderResult();
      } else {
        show("error", "检测未完成，无法判断", result?.error || "检测地址已变化，请重新打开面板。");
      }
    } catch (error) {
      show("error", "检测未完成，无法判断", error.message);
    } finally {
      inspect.disabled = false;
    }
  });
}

setup().catch(error => show("error", "初始化失败", error.message));

const trustPages = {
  local: "chrome://certificate-manager/localcerts",
  user: "chrome://certificate-manager/localcerts/usercerts",
  admin: "chrome://certificate-manager/localcerts/admincerts",
  policy: "chrome://policy",
  "policy-viewer": chrome.runtime.getURL("policy.html")
};

for (const button of document.querySelectorAll("[data-chrome-page]")) {
  button.addEventListener("click", async () => {
    const url = trustPages[button.dataset.chromePage];
    try {
      await chrome.tabs.create({ url });
    } catch {
      element("trust-status").textContent = `请在 Chrome 地址栏手动打开 ${url}`;
    }
  });
}
