const integrationPolicy = "CAPlatformIntegrationEnabled";
const certificatePolicies = ["CACertificates", "CACertificatesWithConstraints"];

function isRecord(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

export function readExportedPolicies(contents) {
  const report = JSON.parse(contents);
  const policies = report?.policyGroups?.chrome?.policies ??
    report?.policyValues?.chrome?.policies ?? report?.chromePolicies;
  if (!isRecord(policies)) throw new Error("文件中未找到 Chrome 浏览器策略。");

  return [integrationPolicy, ...certificatePolicies].map(name => {
    if (!Object.hasOwn(policies, name)) return { name, status: "导出文件未列出" };
    const policy = policies[name];
    if (!isRecord(policy)) return { name, status: "无法识别策略值" };

    let value = policy.value;
    if (typeof value === "string") {
      try {
        value = JSON.parse(value);
      } catch {
        // Unsupported values are reported below.
      }
    }

    const flags = [];
    if (policy.ignored) flags.push("Chrome 标记为忽略");
    if (policy.error) flags.push("Chrome 报告错误");
    if (policy.restartRequired) flags.push("Chrome 标记为需重启");
    let status = "无法识别策略值";
    if (name === integrationPolicy && typeof value === "boolean") {
      status = value ? "true（策略允许系统证书集成）" : "false（策略禁用系统证书集成）";
    } else if (name !== integrationPolicy && Array.isArray(value)) {
      status = `策略记录 ${value.length} 项`;
    }
    return { name, status: [status, ...flags].join(" · ") };
  });
}
