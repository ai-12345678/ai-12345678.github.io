import { httpsUrl } from "./certificate.mjs";
import { inspectCertificate } from "./probe.mjs";

import { compareWithTlsBaseline } from "./external.mjs";

let checking = false;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.remove(["sslLabsEmail", "publicComparison"]).catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "inspect-certificate" || sender.id !== chrome.runtime.id ||
      sender.url !== chrome.runtime.getURL("popup.html")) return false;
  if (checking) {
    sendResponse({ busy: true });
    return false;
  }

  checking = true;
  checkTab(message.tabId, message.origin).then(sendResponse, error => sendResponse({ error: error.message }))
    .finally(() => { checking = false; });
  return true;
});

async function checkTab(tabId, expectedOrigin) {
  const tab = await chrome.tabs.get(tabId);
  const { origin } = httpsUrl(tab.url);
  if (origin !== expectedOrigin) throw new Error("检测地址已变化，请重新打开面板。");
  let result;
  try {
    result = await inspectCertificate(tab);
  } catch (error) {
    result = { origin, checkedAt: Date.now(), error: error.message };
  }
  if (!result.error) result.tlsBaseline = await compareWithTlsBaseline(result);
  await chrome.storage.session.set({ lastCheck: result });
  return result;
}
